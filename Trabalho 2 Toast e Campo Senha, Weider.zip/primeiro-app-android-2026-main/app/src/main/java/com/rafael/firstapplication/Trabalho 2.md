# Trabalho 2 - Toast e Campo Senha

Evolução da aplicação Android desenvolvida em sala de aula utilizando **Kotlin**, **ViewBinding** e layouts **XML**.

## 📋 O que foi implementado
- Adição de um novo `EditText` (`editTextPassword`) no `activity_main.xml` configurado com `android:inputType="textPassword"`.
- Atualização da `MainActivity.kt` utilizando `ViewBinding` para capturar o e-mail e a senha digitados.
- Exibição dos dados formatados em um `Toast` ao clicar no botão **Entrar**:
  ```text
  Email: exemplo@teste.com
  Senha: 123456