package com.rafael.firstapplication

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.rafael.firstapplication.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    // Declaração do ViewBinding para acessar os elementos do XML
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        enableEdgeToEdge()
        setContentView(view)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Referenciando os campos de e-mail, senha e o botão via ViewBinding
        val editText = binding.editText
        val editTextPassword = binding.editTextPassword
        val button = binding.button

        // Evento de clique do botão "Entrar"
        button.setOnClickListener { view ->
            // Obtém os textos digitados nos campos de e-mail e senha
            val email = editText.text.toString()
            val senha = editTextPassword.text.toString()

            // Monta a mensagem com quebra de linha (\n) no formato pedido
            val mensagem = "Email: $email\nSenha: $senha"

            // Exibe o e-mail e a senha em um Toast na tela
            Toast.makeText(this, mensagem, Toast.LENGTH_LONG).show()
        }
    }
}